package com.example.server.request_;

public class ClearRequest {
}
